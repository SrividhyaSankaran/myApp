package com.code.myApp.Exceptions;

public class BadRequestAlertException {
	
	private static final long serialVersionUID = 1L;
	
	public BadRequestAlertException(ErrorCodeMessage errorCodeMessage) {
		
		super();
	}

}
